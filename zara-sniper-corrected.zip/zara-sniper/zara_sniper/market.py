import aiohttp
from datetime import datetime, timezone

BASE = 'https://api.dexscreener.com'

async def fetch_latest_profiles(session):
    async with session.get(f'{BASE}/token-profiles/latest/v1', timeout=aiohttp.ClientTimeout(total=15)) as r:
        r.raise_for_status()
        data = await r.json()
    return [x for x in data if x.get('chainId') == 'solana' and x.get('tokenAddress')]

async def token_pairs(session, mint):
    async with session.get(f'{BASE}/token-pairs/v1/solana/{mint}', timeout=aiohttp.ClientTimeout(total=15)) as r:
        if r.status != 200:
            return []
        data = await r.json()
    return [p for p in data if p.get('chainId') == 'solana'] if isinstance(data, list) else []

def pair_metrics(pair):
    liq = (pair.get('liquidity') or {}).get('usd') or 0
    vol = (pair.get('volume') or {}).get('h24') or 0
    created = pair.get('pairCreatedAt')
    age_hours = None
    if created:
        age_hours = max(0, (datetime.now(timezone.utc).timestamp()*1000 - created)/3600000)
    return float(liq), float(vol), age_hours

def best_pair(pairs, mint=None):
    if mint:
        pairs = [p for p in pairs if (p.get('baseToken') or {}).get('address') == mint]
    return max(pairs, key=lambda p: float((p.get('liquidity') or {}).get('usd') or 0), default=None)

async def search_pairs(session, query):
    async with session.get(f'{BASE}/latest/dex/search', params={'q': query}, timeout=aiohttp.ClientTimeout(total=15)) as r:
        r.raise_for_status()
        data = await r.json()
    return [p for p in data.get('pairs', []) if p.get('chainId') == 'solana']
