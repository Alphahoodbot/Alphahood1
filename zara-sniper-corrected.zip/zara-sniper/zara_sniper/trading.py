"""Real Solana swap execution adapters for ZARA SNIPER.

Live transactions are sent only when TRADING_MODE=live and the owner has configured
wallet/RPC/API secrets. This module never asks for a private key in Telegram.
"""
import asyncio
import base64
import json
import logging
from datetime import datetime, timezone
from typing import Any

import aiohttp
import base58
from solders.keypair import Keypair
from solders.message import to_bytes_versioned
from solders.transaction import VersionedTransaction

from .config import config

log = logging.getLogger("zara-sniper.trading")
SOL_MINT = "So11111111111111111111111111111111111111112"
LAMPORTS_PER_SOL = 1_000_000_000
JUP_BASE = "https://api.jup.ag/swap/v2"
PUMPPORTAL_LOCAL = "https://pumpportal.fun/api/trade-local"

class TradeError(RuntimeError):
    pass

class LiveTrader:
    def __init__(self, session: aiohttp.ClientSession):
        self.session = session
        if config.trading_mode != "live":
            raise TradeError("TRADING_MODE is not live; live transaction execution is disabled.")
        if not config.solana_rpc_url:
            raise TradeError("SOLANA_RPC_URL is missing.")
        if not config.solana_private_key:
            raise TradeError("SOLANA_PRIVATE_KEY is missing. Never send it through Telegram.")
        if not config.jupiter_api_key:
            log.warning("JUPITER_API_KEY missing; Jupiter trades will be unavailable. PumpPortal adapter can still be used.")
        self.keypair = self._load_keypair(config.solana_private_key)
        self.rpc_id = 0

    @staticmethod
    def _load_keypair(value: str) -> Keypair:
        value = value.strip()
        try:
            if value.startswith("["):
                raw = bytes(json.loads(value))
            else:
                raw = base58.b58decode(value)
            if len(raw) == 32:
                return Keypair.from_seed(raw)
            if len(raw) == 64:
                return Keypair.from_bytes(raw)
            raise ValueError("private key must decode to 32 or 64 bytes")
        except Exception as exc:
            raise TradeError("SOLANA_PRIVATE_KEY format is invalid. Use a base58 key or JSON byte array.") from exc

    @property
    def public_key(self) -> str:
        return str(self.keypair.pubkey())

    async def rpc(self, method: str, params: list[Any]) -> Any:
        self.rpc_id += 1
        payload = {"jsonrpc": "2.0", "id": self.rpc_id, "method": method, "params": params}
        async with self.session.post(config.solana_rpc_url, json=payload, timeout=aiohttp.ClientTimeout(total=25)) as resp:
            resp.raise_for_status()
            data = await resp.json(content_type=None)
        if data.get("error"):
            raise TradeError(f"Solana RPC {method} failed: {data['error'].get('message', 'unknown error')}")
        return data.get("result")

    async def sol_balance(self) -> float:
        result = await self.rpc("getBalance", [self.public_key, {"commitment": "confirmed"}])
        return int(result["value"]) / LAMPORTS_PER_SOL

    async def token_balance(self, mint: str) -> tuple[int, int, float]:
        result = await self.rpc("getTokenAccountsByOwner", [self.public_key, {"mint": mint}, {"encoding": "jsonParsed", "commitment": "confirmed"}])
        raw_total, decimals = 0, 0
        for item in result.get("value", []):
            info = item["account"]["data"]["parsed"]["info"]["tokenAmount"]
            raw_total += int(info.get("amount", "0"))
            decimals = int(info.get("decimals", 0))
        return raw_total, decimals, raw_total / (10 ** decimals) if decimals >= 0 else 0.0

    async def _simulate_transaction(self, encoded_tx: str) -> None:
        """Run an RPC simulation before signing/submission; fail closed on simulation errors."""
        try:
            result = await self.rpc("simulateTransaction", [
                encoded_tx,
                {"encoding": "base64", "sigVerify": False, "replaceRecentBlockhash": True,
                 "commitment": "confirmed"}
            ])
        except Exception as exc:
            raise TradeError(f"Transaction simulation unavailable; no transaction sent ({type(exc).__name__}).") from exc
        value = (result or {}).get("value") or {}
        if value.get("err") is not None:
            logs = value.get("logs") or []
            detail = "; ".join(str(x) for x in logs[-3:])
            raise TradeError(f"Transaction simulation failed; no transaction sent. Error: {value.get('err')}; {detail[:300]}")

    async def _wait_for_signature(self, signature: str, attempts: int = 24) -> str:
        for _ in range(attempts):
            status_result = await self.rpc("getSignatureStatuses", [[signature], {"searchTransactionHistory": True}])
            status = (status_result.get("value") or [None])[0]
            if status:
                if status.get("err") is not None:
                    raise TradeError(f"Transaction failed on-chain. Signature: {signature}; error: {status['err']}")
                if status.get("confirmationStatus") in ("confirmed", "finalized"):
                    return signature
            await asyncio.sleep(2)
        raise TradeError(f"Transaction submitted but RPC confirmation is still unknown. DO NOT repeat it yet. Check signature: {signature}")

    async def _sign_and_send(self, encoded_tx: str) -> str:
        await self._simulate_transaction(encoded_tx)
        try:
            unsigned = VersionedTransaction.from_bytes(base64.b64decode(encoded_tx))
            sig = self.keypair.sign_message(to_bytes_versioned(unsigned.message))
            signed = VersionedTransaction.populate(unsigned.message, [sig])
            raw = base64.b64encode(bytes(signed)).decode("ascii")
        except Exception as exc:
            raise TradeError(f"Could not sign transaction: {type(exc).__name__}. No transaction sent.") from exc
        result = await self.rpc("sendTransaction", [raw, {"encoding": "base64", "skipPreflight": False, "preflightCommitment": "confirmed", "maxRetries": 3}])
        signature = result if isinstance(result, str) else result.get("value")
        if not signature:
            raise TradeError("RPC did not return a transaction signature.")
        # Do not blindly resubmit if confirmation is delayed: the first transaction may land.
        return await self._wait_for_signature(signature)

    async def _sign_transaction(self, encoded_tx: str) -> str:
        await self._simulate_transaction(encoded_tx)
        try:
            unsigned = VersionedTransaction.from_bytes(base64.b64decode(encoded_tx))
            sig = self.keypair.sign_message(to_bytes_versioned(unsigned.message))
            signed = VersionedTransaction.populate(unsigned.message, [sig])
            return base64.b64encode(bytes(signed)).decode("ascii")
        except Exception as exc:
            raise TradeError(f"Could not sign transaction: {type(exc).__name__}. No transaction sent.") from exc

    async def jupiter_swap(self, input_mint: str, output_mint: str, amount_raw: int, slippage_bps: int) -> str:
        if amount_raw <= 0:
            raise TradeError("Trade amount is zero.")
        headers = {"accept": "application/json"}
        if config.jupiter_api_key:
            headers["x-api-key"] = config.jupiter_api_key
        params = {"inputMint": input_mint, "outputMint": output_mint, "amount": str(amount_raw), "taker": self.public_key, "slippageBps": str(slippage_bps)}
        async with self.session.get(f"{JUP_BASE}/order", params=params, headers=headers, timeout=aiohttp.ClientTimeout(total=25)) as resp:
            body = await resp.json(content_type=None)
            if resp.status >= 400:
                raise TradeError(f"Jupiter order rejected ({resp.status}): {str(body)[:240]}")
        tx = body.get("transaction")
        request_id = body.get("requestId")
        if not tx or not request_id:
            reason = body.get("errorMessage") or body.get("error") or "No route/transaction returned"
            raise TradeError(f"Jupiter returned no executable order: {str(reason)[:200]}. No transaction sent.")
        signed_tx = await self._sign_transaction(tx)
        execute_body = {"signedTransaction": signed_tx, "requestId": request_id}
        async with self.session.post(f"{JUP_BASE}/execute", json=execute_body, headers=headers, timeout=aiohttp.ClientTimeout(total=35)) as resp:
            result = await resp.json(content_type=None)
            if resp.status >= 400:
                raise TradeError(f"Jupiter execute rejected ({resp.status}): {str(result)[:240]}")
        status = str(result.get("status", "")).lower()
        signature = result.get("signature") or result.get("txid")
        if status not in ("success", "successful", "confirmed") or not signature:
            raise TradeError(f"Jupiter execution not confirmed: {str(result)[:400]}. Check Jupiter/order status before retrying.")
        # Treat Jupiter's response as submission metadata only; verify final chain status through RPC.
        return await self._wait_for_signature(str(signature))

    async def pumpportal_swap(self, action: str, mint: str, amount: str | float, denominated_in_sol: bool, slippage_pct: float) -> str:
        if action not in ("buy", "sell"):
            raise TradeError("Invalid PumpPortal action.")
        # PumpPortal's local transaction API returns an unsigned serialized Solana transaction.
        payload = {
            "publicKey": self.public_key,
            "action": action,
            "mint": mint,
            "amount": str(amount) if isinstance(amount, str) else float(amount),
            "denominatedInSol": "true" if denominated_in_sol else "false",
            "slippage": float(slippage_pct),
            "priorityFee": max(0.00001, config.priority_fee_lamports / LAMPORTS_PER_SOL),
            "pool": "auto",
        }
        async with self.session.post(PUMPPORTAL_LOCAL, json=payload, timeout=aiohttp.ClientTimeout(total=25)) as resp:
            raw = await resp.read()
            if resp.status >= 400:
                raise TradeError(f"PumpPortal rejected trade ({resp.status}): {raw[:240].decode('utf-8', 'replace')}")
        try:
            encoded = base64.b64encode(raw).decode("ascii")
            # Some errors are JSON text instead of transaction bytes.
            if raw[:1] == b"{":
                raise TradeError(raw[:240].decode("utf-8", "replace"))
            return await self._sign_and_send(encoded)
        except TradeError:
            raise
        except Exception as exc:
            raise TradeError(f"Could not parse PumpPortal transaction: {type(exc).__name__}") from exc

    async def buy(self, mint: str, amount_sol: float, engine: str, slippage_bps: int) -> str:
        if amount_sol <= 0 or amount_sol > config.max_position_sol:
            raise TradeError(f"Buy amount must be > 0 and <= MAX_POSITION_SOL ({config.max_position_sol} SOL).")
        bal = await self.sol_balance()
        reserve = 0.01  # keep a small SOL reserve for fees and account rent
        if amount_sol + reserve >= bal:
            raise TradeError(f"Insufficient SOL after keeping {reserve} SOL reserve. Current balance: {bal:.6f} SOL.")
        if engine == "pumpfun":
            sig = await self.pumpportal_swap("buy", mint, amount_sol, True, max(0.5, slippage_bps / 100))
        else:
            sig = await self.jupiter_swap(SOL_MINT, mint, int(amount_sol * LAMPORTS_PER_SOL), slippage_bps)
        return sig

    async def sell_all(self, mint: str, engine: str, slippage_bps: int) -> str:
        raw, decimals, human = await self.token_balance(mint)
        if raw <= 0:
            raise TradeError("No token balance found in this wallet for that mint.")
        if engine == "pumpfun":
            sig = await self.pumpportal_swap("sell", mint, "100%", False, max(0.5, slippage_bps / 100))
        else:
            sig = await self.jupiter_swap(mint, SOL_MINT, raw, slippage_bps)
        return sig

    async def wallet_summary(self) -> str:
        bal = await self.sol_balance()
        return f"Wallet: {self.public_key}\nSOL balance: {bal:.6f} SOL\nNetwork: Solana mainnet RPC configured"

async def check_rpc(session: aiohttp.ClientSession, rpc_url: str) -> bool:
    async with session.post(rpc_url, json={"jsonrpc":"2.0","id":1,"method":"getHealth"}, timeout=aiohttp.ClientTimeout(total=10)) as resp:
        if resp.status >= 400:
            return False
        data = await resp.json(content_type=None)
        return data.get("result") == "ok"
